<?php
// Register the routes under the 'storefront' namespace
add_action('rest_api_init', function () {
    register_rest_route('storefront/v1', '/submit-data', array(
        'methods' => 'POST',
        'callback' => 'storefront_submit_data',
        'permission_callback' => 'authenticate_request',
    ));

    register_rest_route('storefront/v1', '/get-orders', array(
        'methods' => 'GET',
        'callback' => 'storefront_get_orders',
        'permission_callback' => 'authenticate_request',
    ));
});

// Function to handle data submission
function storefront_submit_data($request) {
    $params = $request->get_json_params();

    // Validate the data
    if (empty($params['name']) || empty($params['email']) || empty($params['contact_no']) || empty($params['subscription_term'])) {
        return new WP_Error('missing_data', 'Required fields are missing', array('status' => 400));
    }

    // Establish the database connection
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
    if ($conn->connect_error) {
        return new WP_Error('db_error', 'Database connection failed', array('status' => 500));
    }

    $email = $conn->real_escape_string($params['email']);

    // Check if the email already exists
    $check_email_query = "SELECT * FROM users WHERE email = '$email'";
    $result = $conn->query($check_email_query);
    
    if ($result->num_rows > 0) {
        return new WP_Error('email_exists', 'Email already exists', array('status' => 409)); // 409: Conflict
    }

    // Sanitize input
    $name = $conn->real_escape_string($params['name']);
    $contact_no = $conn->real_escape_string($params['contact_no']);
    $subscription_term = $conn->real_escape_string($params['subscription_term']);

    // Insert into users table
    $insert_user = "INSERT INTO users (name, email, contact_no) VALUES ('$name', '$email', '$contact_no')";
    if ($conn->query($insert_user)) {
        $user_id = $conn->insert_id;
        $insert_order = "INSERT INTO orders (user_id, subscription_term) VALUES ('$user_id', '$subscription_term')";
        if ($conn->query($insert_order)) {
            return array('message' => 'Data successfully submitted');
        } else {
            return new WP_Error('db_insert_error', 'Failed to insert order', array('status' => 500));
        }
    } else {
        return new WP_Error('db_insert_error', 'Failed to insert user', array('status' => 500));
    }
}


// Function to handle retrieving orders
function storefront_get_orders() {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
    if ($conn->connect_error) {
        return new WP_Error('db_error', 'Database connection failed', array('status' => 500));
    }

    $query = "SELECT o.ID, u.name, u.email, u.contact_no, o.subscription_term FROM orders o
              JOIN users u ON o.user_id = u.ID";
    $result = $conn->query($query);
    if ($result->num_rows > 0) {
        $orders = array();
        while ($row = $result->fetch_assoc()) {
            $orders[] = $row;
        }
        return $orders;
    } else {
        return array('message' => 'No orders found');
    }
}
?>
