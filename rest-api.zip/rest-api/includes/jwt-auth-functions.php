<?php

// Include the JWT library directly from the plugin's directory
require_once plugin_dir_path(__FILE__) . '../php-jwt/src/JWT.php'; // Correct path based on your structure

use \Firebase\JWT\JWT;

function generate_jwt_token($user_id) {
    $issuedAt = time();
    $expiration = $issuedAt + 3600; // 1 hour validity
    $payload = array(
        'iat' => $issuedAt,
        'exp' => $expiration,
        'data' => array(
            'user_id' => $user_id
        )
    );
    return JWT::encode($payload, JWT_SECRET_KEY);
}

function validate_jwt_token($token) {
    try {
        $decoded = JWT::decode($token, JWT_SECRET_KEY, array('HS256'));
        return $decoded->data->user_id;
    } catch (Exception $e) {
        return null;
    }
}

function authenticate_request(WP_REST_Request $request) {
    $auth_header = $request->get_header('Authorization');
    if (!$auth_header) {
        return new WP_Error('missing_auth_header', 'Authorization header is missing', array('status' => 403));
    }

    $token = str_replace('Bearer ', '', $auth_header);
    $user_id = validate_jwt_token($token);

    if ($user_id) {
        return true;
    } else {
        return new WP_Error('invalid_token', 'Invalid JWT token', array('status' => 403));
    }
}
?>
