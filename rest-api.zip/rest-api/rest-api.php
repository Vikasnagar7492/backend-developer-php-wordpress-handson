<?php
/*
Plugin Name: REST API Plugin
Description: A custom REST API plugin for managing users and orders.
Version: 1.0
Author: Vikas Nagar
*/


// // Define database connection constants using environment variables
// define('DB_HOST', $_ENV['DB_HOST']);
// define('DB_USER', $_ENV['DB_USER']);
// define('DB_PASSWORD', $_ENV['DB_PASSWORD']);
// define('DB_NAME', $_ENV['DB_NAME']);
 define('JWT_SECRET_KEY', 'onecom');

// Create tables on plugin activation
register_activation_hook(__FILE__, 'storefront_create_tables');

function storefront_create_tables() {
    // Database connection
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Create users table
    $create_users_table = "CREATE TABLE IF NOT EXISTS users (
        ID INT(11) AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) UNIQUE NOT NULL,
        contact_no VARCHAR(15) NOT NULL
    )";

    // Create orders table
    $create_orders_table = "CREATE TABLE IF NOT EXISTS orders (
        ID INT(11) AUTO_INCREMENT PRIMARY KEY,
        user_id INT(11) NOT NULL,
        subscription_term VARCHAR(50) NOT NULL,
        FOREIGN KEY (user_id) REFERENCES users(ID)
    )";

    $conn->query($create_users_table);
    $conn->query($create_orders_table);

    $conn->close();
}

// Include JWT authentication and API functionality
require_once plugin_dir_path(__FILE__) . 'includes/jwt-auth-functions.php';
require_once plugin_dir_path(__FILE__) . 'includes/api-functions.php';
?>
